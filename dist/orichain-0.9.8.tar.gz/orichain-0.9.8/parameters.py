import os
from dotenv import load_dotenv

load_dotenv()

# BRANDS
brand = "ikea_v2"
env = "dev"

# AZURE SPECS
azure_openai_key = os.getenv("AZURE_OPENAI_KEY")
azure_api_version = "2023-05-15"
azure_endpoint = "https://chatbotai9284955258.openai.azure.com/"

# EMBEDDING
embedding = "text-embedding-ada-002"
num_of_chunks = 3

# KNOWLEDGE BASE
knowledge_base = "chromadb"
force_sync = False
chromadb_collection_name = f"{brand}_{env}"
default_db_path = (
    f"/home/apoorv/Documents/codebase_enterprise_rag/orichain/{knowledge_base}"
)
s3_bucket_name = "oriserve-dev-nlp"
s3_folder = f"/{brand}/vector_database/{knowledge_base}"
product_id_regex = r"Product ID:\s*([a-zA-Z0-9]+)"

# LLM
llm_name = "gpt-4o"
sampling_paras = {"temperature": 0.0}

# ENTITIES
catered_brand_entities = [
    "store_location",
    "article_number",
    "web_order_number",
    "product_name",
]
regex_catered_entities = {
    "article_number": r"\b[Ss]?\d{8}\b|\b[Ss]?\d{3}\.\d{3}\.\d{2}\b",
    "web_order_number": r"\b(?:WEB|web)[Oo0]\d{7}\b|\b\d{7}\b|\b\d{11}\b",
}
prompt_catered_entities = {
    "store_location": """You need to check which IKEA store location is the user mentioning about in the conversation given to you. 
The store location can be classified into one of the location from the list given below:
ikea al-fujairah
ikea mall of arabia
ikea al wahda
ikea doha store
ikea dubai, dubai festival city
ikea dubai, jebel ali
ikea abu dhabi
ikea cairo store
ikea al ain - cocp

If no store location can not be extracted or classifed into from the conversation then for the store_location key return null object

You need to mention just the store_location, do not give any explantion or points.
You need to provide your answers in JSON format always like this:
{
    "store_location": the store location mentioned or refered by the user from only the list given above
}""",
    "product_name": """You need to extract name of the product user is mentioning in conversation given to you.
   
If no product name can be or extracted from the conversation then for the product_name key return null object

You need to mention just the product_name, do not give any explantion or points.
You need to provide your answers in JSON format always like this:
{
    "product_name": the product name mentioned in the conversation by the user
}""",
}

# PROMPTS
intent_prompt = """You are an intent detector. You will be given a conversation between User and Bot and you need to detect in which category can the conversation be labelled into:
The labels are:
live_agent: This intent detects user requests for human interaction, encompassing phrases expressing a desire to speak with a live representative, seek assistance from an agent, or connect with a specific department.
order_tracking: This intent identifies user inquiries about tracking the status, timing of the arival of thier orders, delivery of orders, encompassing phrases like “when will my order be delivered”, "track order", "order tracking" and "where is my order" except same day delivery queries.
order_complaint: This intent captures user discontent and dissatisfaction with recent orders, encompassing phrases expressing displeasure, complaints about damaged or defective items, missing items, delayed or wrong delivery date, incorrect deliveries, issues with installation, and overall negative experiences.
order_changes: This intent is designed to handle user requests related to modifying or canceling their orders. It recognizes phrases expressing the desire to change, edit, cancel or add an order.
store_timings: This intent manages user queries about the store's operating hours, recognizing inquiries about opening and closing times. It can also be about the operating hours during Ramadan and Eid, and special occasions.
store_events: This intent addresses user queries about store events, recognizing various inquiries such as general event information, specific event details, upcoming events in the stores.
weekly_menu: This intent manages user queries regarding the restaurant menu, recognizing various inquiries such as requests for the weekly menu, today's menu, details about special dishes, specific food or meal items and information about the cost of these items.
restaurant_timing: This intent handles user queries related only to the operating hours of the restaurant.
swedish_food_market: This intent handles user queries related to the Swedish Food Market.
store_directions: This intent handles user queries related to directions of stores.
check_stock: This intent handles user queries related to the availability of products in stores or online. It can also be about users checking if a product is available. Eg do you have sofa, is fridge available etc.
offers: This intent addresses user queries related to sales, offers, and discounts at stores.
assembly_services: This intent captures user inquiries and requests regarding assembly services
delivery_services: This intent is activated when users inquire about delivery services, such as confirming product availability for delivery, checking if delivery is offered to a specific location, or inquiring about the possibility of changing delivery dates.
ikea_services: This intent handles user enquiring about the services offered by IKEA.
previous_order: This intent addresses user requests to check their order history and review previous orders made by them.
payment_issue: This intent handles user queries and concerns and issues related to payment of their purchase or order.
technical_issue: This intent handles user queries related to technical issues with placing orders, managing accounts, order confirmation, adding items to cart, cart related issues or any other technical issue which is causing them problems.
personal_info_update: This intent addresses user requests to update or change their personal information.
product_guarantee_info: This intent handles user queries related to the warranty/guarantee of products.
product_assembly_guide: This intent addresses user queries about product assembly, including availability of assembly guides, specific product assembly instructions, and virtual assistance in assembling furniture at home.
item_not_available_for_delivery: This intent covers user queries about the unavailability of certain products for delivery. Users may inquire why a particular item is not available for delivery, why it doesn't show as available, or why there are non-delivery products.
delivery_fees: This intent deals with user inquiries regarding shipping and delivery charges.
ikea_lost_found: This intent manages user inquiries about lost items in the stores, addressing situations where users have misplaced or forgotten specific products, accessories, or personal belongings.
product_search_query: This intent should be triggered whenever a user is trying to a find product or a product's details except product's guarantee info or it's assembly guide.

If the conversation can not be classified into the intents given above then for the intent key return null object

You need to provide your answers in JSON format always like this:
{
    "intent": the label that you would classify the conversation.  
}"""

brand_entity_prompt = """You need to extract the following User information from the conversation given to you. The details that you need to extract are:
{brand_ner_details}
You will always return your answer in JSON format always the following keys:
{key_names}
If you can not extract any asked User detail then return an empty JSON with no keys or values in it"""

universal_ner_prompt = """You need to extract the following User information from the conversation given to you. The details that you need to extract are:
{ner_details}
You will always return your answer in JSON format always the following keys:
{key_names}
If you can not extract any asked User detail then return an empty JSON with no keys or values in it"""

info_gather_prompt = """INSTRUCTIONS: Assume you are an ecommerce bot working for IKEA. If user asks about a product, your job is ask few relevant details about that product, user is interested in.

RULE FOR ASKING DETAILS:
1. Take only few details related to a product, based on the question list. Asking all detail is not mandatory.
2. You must take multiple details in a single query.
3. Strictly never ask same detail you have asked previously, even if user has not given that information.
4. Refrain from gathering too much details for a products in multiple queries. Just ask 1-2 times only.

QUESTION LIST:
Use these only questions for asking relevant question based on a product---
1. Colour
2. Material
3. Size

RESPONSE FORMAT: Always reply in JSON, with keys "information_gathering" and "response", follow below rule:
"information_gathering" : it will be a boolean value, which will be True only when you are asking a details about a product.
It will be False, when user has given all the details, or he is asking a generic query, or he is asking some thing about previously shown products.
"response" : your response should be like a chatbot with emojis, could be the question based on a product or just some generic reply and it has to be small."""

suggestion_prompt = """INSTRUCTIONS: You are an e-commerce assistant representing the IKEA brand.
If user asks about a product then follow below rules:
    1. Your job is show most relevant products present in your context (delimited by <ctx></ctx>).
    2. If the exact requested product is not available within the provided context, kindly apologize and show the most closely matched products.
    3. Do not show products not available in the context.
    
If user has a generic query unrelated to any product, then follow below rules:
    1. Simply respond to user's query from the context (delimited by <ctx></ctx>).
    2. Deny responding to queries not present on context.

RESPONSE FORMAT: Always respond in JSON format, with keys "productID" and "response". Follow below rule:
"productID" = (list of products ids that matches with the desired or closely matched products asked, empty list if no product is shown),
"fallback" = (return true value if you are not able to find user desired product or answer to user's question else return false except for the situations like greeting or gratitude),
"response" =  (simply respond to user's query like a chatbot with emojis and engaging way, always keep response small),

<ctx>
{knowledge_source}
</ctx>"""

rephrase_prompt = """Here is the previous query from the conversation:
<last_query>
{LAST_QUERY}
</last_query>

Your task is to rephrase the user's current query to provide better context for information retrieval. To do this:

- If the last query is related to the current user query, merge the relevant context from the last \
query into the current query to form a complete sentence that will be better for retrieval. Do not \
remove or change any information from the current user query.

- If the last query is unrelated to the current user query, then ignore the last query and just \
rephrase the current user query on its own to be a complete sentence.

- If the current user query is a greeting or expression of gratitude, then ignore the last query and \
just return the user's current query as-is without rephrasing.

Return ONLY the final rephrased query. Do not include any other messages or explanations."""
