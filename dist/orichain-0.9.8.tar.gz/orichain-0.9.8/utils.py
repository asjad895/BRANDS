from typing import Dict, List, Union, Any, Optional, AsyncGenerator, Tuple
from collections import OrderedDict
import subprocess
import traceback
import json
import re

import os
import boto3

from orichain import validate_gen_response_request, validate_result_request
from orichain.lang_detect import LanguageDetection

from fastapi import Request
import asyncio

__import__("pysqlite3")
import sys

sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
import chromadb

from orichain.knowledge_base import KnowledgeBase
from orichain.embeddings import EmbeddingModels
from orichain.llm import LLM

import parameters

lang_detect = LanguageDetection(languages=["ENGLISH", "ARABIC"])

embedding_model = EmbeddingModels(
    model_name=parameters.embedding,
    api_key=parameters.azure_openai_key,
    azure_endpoint=parameters.azure_endpoint,
    api_version=parameters.azure_api_version,
    use_azure_openai=True,
)

llm = LLM(
    model_name=parameters.llm_name,
    api_key=parameters.azure_openai_key,
    azure_endpoint=parameters.azure_endpoint,
    api_version=parameters.azure_api_version,
    use_azure_openai=True,
)


class VectorDatabase(object):
    class MyEmbeddingFunction(chromadb.EmbeddingFunction):
        def __call__(self, input: chromadb.Documents) -> chromadb.Embeddings:
            embeddings = []
            for text in input:
                embeddings.append(embedding_model(user_message=text))
            return embeddings

    def __init__(self) -> KnowledgeBase:
        if not os.path.exists(parameters.default_db_path) or parameters.force_sync:
            print(
                f"Downloading vector data base from {parameters.s3_bucket_name}{parameters.s3_folder} to {parameters.default_db_path}"
            )
            self.download_s3_folder(
                bucket_name=parameters.s3_bucket_name,
                s3_folder=parameters.s3_folder,
                local_dir=parameters.default_db_path,
            )

        self.knowledge_base_manager = KnowledgeBase(
            type=parameters.knowledge_base,
            collection_name=parameters.chromadb_collection_name,
            embedding_function=self.MyEmbeddingFunction(),
            path=parameters.default_db_path,
        )

    def download_s3_folder(
        self, bucket_name: str, s3_folder: str, local_dir: str
    ) -> None:
        s3resource = boto3.resource("s3")
        bucket = s3resource.Bucket(bucket_name)
        if len(list(bucket.objects.filter(Prefix=s3_folder))):
            for obj in bucket.objects.filter(Prefix=s3_folder):
                target = (
                    obj.key
                    if local_dir is None
                    else os.path.join(local_dir, os.path.relpath(obj.key, s3_folder))
                )
                if not os.path.exists(os.path.dirname(target)):
                    os.makedirs(os.path.dirname(target))
                if obj.key[-1] == "/":
                    continue
                bucket.download_file(obj.key, target)
        else:
            raise FileNotFoundError(f"{s3_folder} does not exist in {bucket_name}")

    async def knowledge_base_retriever(
        self, user_message: str, prev_chunks: Optional[List[str]]
    ) -> Dict:
        # Embedding creation for retrieval
        user_message_vector = await embedding_model(user_message=user_message)

        # Checking for error while embedding generation
        if isinstance(user_message_vector, Dict):
            return user_message_vector

        # Fetching relevant data chunks from knowledgebase
        retrieved_chunks_task = self.knowledge_base_manager(
            user_message_vector=user_message_vector,
            num_of_chunks=parameters.num_of_chunks,
        )

        if prev_chunks:
            prev_chunk_clubbed_data = "\n\n".join(prev_chunks)
            prev_product_ids = re.findall(
                parameters.product_id_regex, prev_chunk_clubbed_data
            )
            if prev_product_ids:
                prev_retrieved_chunks_task = self.knowledge_base_manager.fetch(
                    ids=prev_product_ids
                )
                retrieved_chunks, prev_retrieved_chunks = await asyncio.gather(
                    retrieved_chunks_task, prev_retrieved_chunks_task
                )

                if "error" in retrieved_chunks:
                    return retrieved_chunks
                elif "error" in prev_retrieved_chunks:
                    return prev_retrieved_chunks
                else:
                    pass

                retrieved_chunks = await self.merge_dicts(
                    retrieved_chunks=retrieved_chunks,
                    prev_retrieved_chunks=prev_retrieved_chunks,
                )
                print(retrieved_chunks)
            else:
                retrieved_chunks = await retrieved_chunks_task
        else:
            retrieved_chunks = await retrieved_chunks_task

        return retrieved_chunks

    async def merge_dicts(
        self, retrieved_chunks: Dict, prev_retrieved_chunks: Dict
    ) -> Dict:
        # Initialize the result dictionary by copying retrieved_chunks
        merged_dict = {}

        # Merge 'ids'
        merged_dict["ids"] = [
            retrieved_chunks["ids"][0] + (prev_retrieved_chunks["ids"])
        ]

        # Merge 'metadatas'
        merged_dict["metadatas"] = [
            retrieved_chunks["metadatas"][0] + prev_retrieved_chunks["metadatas"]
        ]

        # Merge 'documents'
        merged_dict["documents"] = [
            retrieved_chunks["documents"][0] + prev_retrieved_chunks["documents"]
        ]

        return merged_dict

    def restart_gunicorn(self):
        try:
            print("Gunicorn service restart starting.")
            subprocess.run(
                ["sudo", "systemctl", "restart", "gunicorn.service"], check=True
            )
        except subprocess.CalledProcessError as e:
            print(f"Error restarting Gunicorn service: {e}")


vector_db = VectorDatabase()


async def generative_request_validation(
    user_message,
    metadata,
    prev_pairs,
    prev_chunks,
) -> Union[Dict, None]:
    if (
        prev_pairs
        and isinstance(prev_pairs, List)
        and isinstance(prev_pairs[0], Dict)
        and prev_pairs[0].get("role") == "assistant"
    ):
        prev_pairs.insert(0, {"role": "user", "content": "hi"})

    validation_check = await validate_gen_response_request(
        user_message=user_message,
        metadata=metadata,
        prev_pairs=prev_pairs,
        prev_chunks=prev_chunks,
    )

    # Add more validation steps if needed...

    return validation_check


async def results_request_validation(
    user_message,
    bot_message,
    intent,
    brand_entity,
    universal_ner,
) -> Union[Dict, None]:
    validation_check = await validate_result_request(
        user_message=user_message,
        bot_message=bot_message,
        intent=intent,
        brand_entity=brand_entity,
        universal_ner=universal_ner,
    )

    if validation_check:
        return validation_check

    if brand_entity:
        undefined_brand_elements = set(brand_entity.get("list_of_entities", [])) - set(
            parameters.catered_brand_entities
        )

        if undefined_brand_elements:
            return {
                "error": 400,
                "reason": f"{list(undefined_brand_elements)} not defined to be catered in brand_entity",
            }

    # Add more validation steps if needed...

    return None


async def process_brand_entity(
    request: Request, user_message: str, whole_chat: str, brand_entities: List, llm: Any
) -> Union[Dict, None]:
    if brand_entities:
        tasks = []
        for entity in brand_entities:
            if entity in parameters.regex_catered_entities:
                task = asyncio.to_thread(
                    re.findall,
                    parameters.regex_catered_entities.get(entity),
                    user_message,
                )
            elif entity in parameters.prompt_catered_entities:
                task = llm(
                    request=request,
                    user_message=whole_chat,
                    system_prompt=parameters.prompt_catered_entities.get(entity),
                    sampling_paras=parameters.sampling_paras,
                    do_json=True,
                )
            else:
                task = None

            tasks.append(task)

        results = await asyncio.gather(*tasks)
        return {
            entity: json.loads(result.get("response")).get(entity)
            if isinstance(result, Dict) and "response" in result
            else result
            for entity, result in zip(brand_entities, results)
        }
    else:
        return None


async def clean_empty_values(data):
    if isinstance(data, Dict):
        return {
            key: await clean_empty_values(values)
            if values is not None or values is False
            else None
            for key, values in data.items()
        }
    return data


async def results_processsing(
    user_message: str,
    bot_message: str,
    request: Request,
    intent: Optional[Dict] = {},
    brand_entity: Optional[Dict] = {},
    universal_ner: Optional[Dict] = {},
    language_detection: Optional[Dict] = {},
) -> Dict:
    try:
        tasks = OrderedDict()
        whole_chat = f"The converstation between User and Bot is given below:\nBot: {bot_message}\nUser: {user_message}"

        if intent.get("trigger"):
            tasks["intent"] = llm(
                request=request,
                user_message=whole_chat,
                system_prompt=parameters.intent_prompt,
                do_json=True,
            )

        # Change it according to the brand usecase
        if brand_entity.get("trigger"):
            brand_entities = brand_entity.get("list_of_entities")
            tasks["brand_entity"] = process_brand_entity(
                request, user_message, whole_chat, brand_entities, llm
            )

        if universal_ner.get("trigger"):
            ner_details = ""

            modifications_of_entities = universal_ner.get("modifications_of_entities")

            if not modifications_of_entities:
                modifications_of_entities = [None] * len(
                    universal_ner.get("list_of_entities")
                )

            for index, tuple_details in enumerate(
                zip(universal_ner.get("list_of_entities"), modifications_of_entities)
            ):
                ner_details += f"\n{tuple_details[0]}"
                if tuple_details[1]:
                    ner_details += f": {tuple_details[1]}"

            key_names = "\n".join(universal_ner.get("list_of_entities"))

            tasks["universal_ner"] = llm(
                request=request,
                user_message=whole_chat,
                system_prompt=parameters.universal_ner_prompt.format(
                    ner_details=ner_details.strip(), key_names=key_names
                ),
                do_json=True,
            )

        if language_detection.get("trigger"):
            tasks["language_detection"] = lang_detect(
                user_message=user_message, add_confidence=False
            )

        if len(tasks) == 0:
            return {}

        results = await asyncio.gather(*tasks.values())

        # Create a dictionary to map task names to their results
        result_map = dict(zip(tasks.keys(), results))

        if result_map.get("intent") and "error" not in result_map.get("intent"):
            intent_result = json.loads(result_map.get("intent").get("response")).get(
                "intent", None
            )
            result_map["intent"] = (
                {"name": intent_result} if intent_result else {"name": None}
            )

        if result_map.get("universal_ner") and "error" not in result_map.get(
            "universal_ner"
        ):
            result_map["universal_ner"] = json.loads(
                result_map.get("universal_ner").get("response")
            )

        result_map = await clean_empty_values(result_map)

        return result_map
    except Exception as e:
        exception_type = type(e).__name__
        exception_message = str(e)
        exception_traceback = traceback.extract_tb(e.__traceback__)
        line_number = exception_traceback[-1].lineno

        print(f"Exception Type: {exception_type}")
        print(f"Exception Message: {exception_message}")
        print(f"Line Number: {line_number}")
        print("Full Traceback:")
        print("".join(traceback.format_tb(e.__traceback__)))
        return {"error": 500, "reason": str(e)}


async def rephaser(
    user_message: str,
    user_context_summary: Optional[str],
    prev_pairs: Optional[List[Dict[str, str]]],
    request: Request,
) -> Union[str, Dict]:
    if user_context_summary:
        result = await llm(
            request=request,
            user_message=user_message,
            system_prompt=parameters.rephrase_prompt.format(
                LAST_QUERY=user_context_summary
            ),
            sampling_paras=parameters.sampling_paras,
        )

        if "error" in result:
            return result
        else:
            return result.get("response")
    elif (
        prev_pairs
        and len(prev_pairs) == 2
        and prev_pairs[-1].get("role") == "assistant"
    ):
        result = await llm(
            request=request,
            user_message=user_message,
            system_prompt=parameters.rephrase_prompt.format(
                LAST_QUERY=prev_pairs[-1].get("content")
            ),
            sampling_paras=parameters.sampling_paras,
        )

        if "error" in result:
            return result
        else:
            return result.get("response")

    else:
        return user_message


async def format_sse(data: Any, event=None) -> str:
    msg = f"data: {json.dumps(data)}\n\n"

    if event is not None:
        msg = f"event: {event}\n{msg}"

    return msg


async def retrieved_chunks_formatter(retrieved_chunks: Dict) -> Tuple[str, Dict, List]:
    retrieved_metadata = {}
    chunks = []

    for product_ids, chunk_details, product_metadatas in zip(
        retrieved_chunks.get("ids"),
        retrieved_chunks.get("documents"),
        retrieved_chunks.get("metadatas"),
    ):
        for product_id, chunk_detail, product_metadata in zip(
            product_ids, chunk_details, product_metadatas
        ):
            chunks.append(f"Product ID: {product_id}\n{chunk_detail}")
            retrieved_metadata[product_id] = product_metadata

    knowledge_source = "\n\n".join(chunks)

    return knowledge_source, retrieved_metadata, chunks


async def custom_streamer(
    request: Request,
    user_message: str,
    prev_pairs: Optional[List[Dict[str, str]]],
    prev_chunks: Optional[List[str]],
) -> AsyncGenerator:
    retrieval_task = asyncio.create_task(
        vector_db.knowledge_base_retriever(
            user_message=user_message, prev_chunks=prev_chunks
        )
    )

    generator = llm.stream(
        request=request,
        user_message=user_message,
        chat_hist=prev_pairs,
        system_prompt=parameters.info_gather_prompt,
        do_json=True,
        do_sse=False,
        sampling_paras=parameters.sampling_paras,
    )

    negative_info_gather_check = '{\n  "information_gathering": false'
    stream_check = '{\n  "information_gathering": true,\n  "response": "'
    do_stream = False
    ending_soon = False
    proceed_for_suggestion = False
    buffer = ""
    async for chunk in generator:
        if isinstance(chunk, str):
            buffer += chunk
        elif isinstance(chunk, Dict):
            if "error" in chunk:
                yield await format_sse(data=chunk, event="body")
                await generator.aclose()
                break
            else:
                buffer_json = json.loads(buffer)
                chunk["response"] = buffer_json["response"]
                chunk["metadata"]["user_context_summary"] = user_message
                chunk["metadata"]["fallback"] = False
                yield await format_sse(data=chunk, event="body")
                await generator.aclose()
                break
        else:
            pass

        if do_stream:
            if isinstance(chunk, str):
                if '"' in chunk:
                    ending_soon = True
                    chunk = chunk.replace('"', "")
                if ending_soon:
                    chunk = chunk.replace("}", "").rstrip()
                if chunk:
                    yield await format_sse(data=chunk, event="text")
        else:
            if buffer == negative_info_gather_check:
                proceed_for_suggestion = True
                await generator.aclose()
                break

            if buffer == stream_check:
                do_stream = True

    if proceed_for_suggestion:
        # Wait for the retrieval task to complete
        retrieved_chunks = await retrieval_task

        if "error" in retrieved_chunks:
            yield await format_sse(data=retrieved_chunks, event="body")
        else:
            (
                knowledge_source,
                retrieved_metadata,
                chunks,
            ) = await retrieved_chunks_formatter(retrieved_chunks=retrieved_chunks)

            generator = llm.stream(
                request=request,
                user_message=user_message,
                system_prompt=parameters.suggestion_prompt.format(
                    knowledge_source=knowledge_source
                ),
                matched_sentence=chunks,
                chat_hist=prev_pairs,
                do_json=True,
                do_sse=False,
                sampling_paras=parameters.sampling_paras,
            )

            buffer = ""
            stream_check = '"response": "'
            do_stream = False
            ending_soon = False

            async for chunk in generator:
                if isinstance(chunk, str):
                    buffer += chunk
                elif isinstance(chunk, Dict):
                    if "error" in chunk:
                        yield await format_sse(data=chunk, event="body")
                        await generator.aclose()
                        break
                    else:
                        buffer_json = json.loads(buffer)
                        chunk["response"] = buffer_json.get("response")
                        chunk["metadata"]["fallback"] = buffer_json.get(
                            "fallback", False
                        )
                        chunk["metadata"]["user_context_summary"] = user_message

                        ai_rec_product_metadata = []
                        if buffer_json.get("productID"):
                            for ids in buffer_json.get("productID"):
                                ai_rec_product_metadata.append(
                                    retrieved_metadata.get(str(ids))
                                )
                            ai_rec_product_metadata = list(
                                filter(lambda x: x is not None, ai_rec_product_metadata)
                            )

                        chunk["metadata"]["ai_searched_product_details"] = (
                            ai_rec_product_metadata if ai_rec_product_metadata else None
                        )
                        yield await format_sse(data=chunk, event="body")
                        await generator.aclose()
                        break
                else:
                    pass

                if do_stream:
                    if isinstance(chunk, str):
                        if '"' in chunk:
                            ending_soon = True
                            chunk = chunk.replace('"', "")
                        if ending_soon:
                            chunk = chunk.replace("}", "").rstrip()
                        if chunk:
                            yield await format_sse(data=chunk, event="text")
                else:
                    if stream_check in buffer:
                        do_stream = True
                    else:
                        pass


async def final_pred(
    request: Request,
    user_message: str,
    prev_pairs: Optional[List[Dict[str, str]]],
    prev_chunks: Optional[List[str]],
) -> Dict:
    info_gather_task = llm(
        request=request,
        user_message=user_message,
        chat_hist=prev_pairs,
        system_prompt=parameters.info_gather_prompt,
        do_json=True,
        sampling_paras=parameters.sampling_paras,
    )

    retrieval_task = vector_db.knowledge_base_retriever(
        user_message=user_message, prev_chunks=prev_chunks
    )

    info_gather_result, retrieved_chunks = await asyncio.gather(
        info_gather_task, retrieval_task
    )

    if "error" in info_gather_result:
        return info_gather_result

    result = json.loads(info_gather_result.get("response"))
    print("info_gather", result)
    if result.get("information_gathering"):
        info_gather_result["response"] = result.get("response")
        info_gather_result["metadata"]["user_context_summary"] = user_message
        info_gather_result["metadata"]["fallback"] = False
        return info_gather_result

    if "error" in retrieved_chunks:
        return retrieved_chunks

    knowledge_source, retrieved_metadata, chunks = await retrieved_chunks_formatter(
        retrieved_chunks=retrieved_chunks
    )

    suggestion_result = await llm(
        request=request,
        user_message=user_message,
        system_prompt=parameters.suggestion_prompt.format(
            knowledge_source=knowledge_source
        ),
        matched_sentence=chunks,
        chat_hist=prev_pairs,
        do_json=True,
        sampling_paras=parameters.sampling_paras,
    )

    if "error" in suggestion_result:
        return suggestion_result

    result = json.loads(suggestion_result.get("response"))
    suggestion_result["response"] = result.get("response")
    suggestion_result["metadata"]["fallback"] = result.get("fallback", False)
    suggestion_result["metadata"]["user_context_summary"] = user_message

    ai_rec_product_metadata = []
    if result.get("productID"):
        for ids in result.get("productID"):
            ai_rec_product_metadata.append(retrieved_metadata.get(str(ids)))
        ai_rec_product_metadata = list(
            filter(lambda x: x is not None, ai_rec_product_metadata)
        )

    suggestion_result["metadata"]["ai_searched_product_details"] = (
        ai_rec_product_metadata if ai_rec_product_metadata else None
    )

    return suggestion_result
