from typing import Any, List, Dict, Optional, Union, AsyncGenerator
import traceback
import json

from fastapi import Request

import asyncio


class Generate(object):
    hf_model_name = {
        "meta.llama3-70b-instruct-v1:0": "meta-llama/Meta-Llama-3-70B-Instruct",
        "meta.llama3-8b-instruct-v1:0": "meta-llama/Meta-Llama-3-8B-Instruct",
        "meta.llama2-70b-chat-v1": "meta-llama/Llama-2-70b-chat-hf",
        "meta.llama2-13b-chat-v1": "meta-llama/Llama-2-13b-chat-hf",
    }

    def __init__(self, **kwds: Any) -> None:
        """
        Initialize AWS Bedrock client and set up API key.

        Args:
            - aws_access_key (str): access key
            - aws_secret_key (str): api key
            - aws_region (str): region name
        """

        if not kwds.get("aws_access_key"):
            raise KeyError("Required 'aws_access_key' not found")
        elif not kwds.get("aws_secret_key"):
            raise KeyError("Required 'aws_secret_key' not found")
        elif not kwds.get("aws_region"):
            raise KeyError("Required aws_region not found")
        else:
            pass

        import boto3
        from botocore.config import Config
        from transformers import AutoTokenizer

        self.client = boto3.client(
            service_name="bedrock-runtime",
            aws_access_key_id=kwds.get("aws_access_key"),
            aws_secret_access_key=kwds.get("aws_secret_key"),
            config=Config(region_name=kwds.get("aws_region"), max_pool_connections=100),
        )
        self.tokenizer = AutoTokenizer.from_pretrained(
            pretrained_model_name_or_path=self.hf_model_name.get(
                kwds.get("model_name")
            ),
            token=kwds.get("token"),
        )

        if not self.tokenizer:
            raise ValueError(
                f"Unable to load tokenizer model for {kwds.get('model_name')}\nThis error should not happen"
            )

    async def __call__(
        self,
        model_name: str,
        user_message: Union[str, List[Dict[str, str]]],
        request: Optional[Request] = None,
        chat_hist: Optional[List[str]] = None,
        sampling_paras: Optional[Dict] = {},
        system_prompt: Optional[str] = None,
        do_json: Optional[bool] = False,
    ) -> Dict:
        try:
            messages = await self._chat_formatter(
                user_message=user_message,
                chat_hist=chat_hist,
                system_prompt=system_prompt,
                do_json=do_json,
            )

            if not isinstance(messages, str):
                return messages

            if request and await request.is_disconnected():
                return {"error": 400, "reason": "request aborted by user"}

            sampling_paras.update({"prompt": messages})

            result = await self._generate_response(
                body=sampling_paras, model_id=model_name, do_json=do_json
            )

            return result

        except Exception as e:
            exception_type = type(e).__name__
            exception_message = str(e)
            exception_traceback = traceback.extract_tb(e.__traceback__)
            line_number = exception_traceback[-1].lineno

            print(f"Exception Type: {exception_type}")
            print(f"Exception Message: {exception_message}")
            print(f"Line Number: {line_number}")
            print("Full Traceback:")
            print("".join(traceback.format_tb(e.__traceback__)))
            return {"error": 500, "reason": str(e)}

    async def streaming(
        self,
        model_name: str,
        user_message: Union[str, List[Dict[str, str]]],
        request: Optional[Request] = None,
        chat_hist: Optional[List[str]] = None,
        sampling_paras: Optional[Dict] = {},
        system_prompt: Optional[str] = None,
        do_json: Optional[bool] = False,
    ) -> AsyncGenerator:
        try:
            messages = await self._chat_formatter(
                user_message=user_message,
                chat_hist=chat_hist,
                system_prompt=system_prompt,
                do_json=do_json,
            )

            if not isinstance(messages, str):
                yield messages
            else:
                sampling_paras.update({"prompt": messages})

                streaming_response = self._stream_response(
                    model_id=model_name, body=sampling_paras
                )

                response = ""
                usage = None
                no_error = True

                if do_json:
                    yield "{"

                async for text in streaming_response:
                    if request and await request.is_disconnected():
                        yield {"error": 400, "reason": "request aborted by user"}
                        await streaming_response.aclose()
                        break
                    elif text and isinstance(text, str):
                        response += text
                        yield text
                    elif isinstance(text, Dict) and "error" not in text:
                        usage = text
                    elif isinstance(text, Dict) and "error" in text:
                        no_error = False
                        yield text
                        await streaming_response.aclose()
                        break
                    else:
                        pass

                if no_error:
                    result = {
                        "response": "{" + response.strip()
                        if do_json
                        else response.strip(),
                        "metadata": {"usage": usage},
                    }

                    yield result

        except Exception as e:
            exception_type = type(e).__name__
            exception_message = str(e)
            exception_traceback = traceback.extract_tb(e.__traceback__)
            line_number = exception_traceback[-1].lineno

            print(f"Exception Type: {exception_type}")
            print(f"Exception Message: {exception_message}")
            print(f"Line Number: {line_number}")
            print("Full Traceback:")
            print("".join(traceback.format_tb(e.__traceback__)))
            yield {"error": 500, "reason": str(e)}

    async def _generate_response(
        self, body: Dict, model_id: str, do_json: Optional[bool] = False
    ) -> Dict:
        try:
            response = await asyncio.to_thread(
                self.client.invoke_model,
                body=json.dumps(body),
                modelId=model_id,
            )

            response_body = json.loads(response.get("body").read())

            result = {
                "response": "{" + response_body.pop("generation")
                if do_json
                else response_body.pop("generation"),
                "metadata": {"usage": response_body},
            }

            return result

        except Exception as e:
            exception_type = type(e).__name__
            exception_message = str(e)
            exception_traceback = traceback.extract_tb(e.__traceback__)
            line_number = exception_traceback[-1].lineno

            print(f"Exception Type: {exception_type}")
            print(f"Exception Message: {exception_message}")
            print(f"Line Number: {line_number}")
            print("Full Traceback:")
            print("".join(traceback.format_tb(e.__traceback__)))
            return {"error": 500, "reason": str(e)}

    async def _stream_response(self, body: Dict, model_id: str) -> AsyncGenerator:
        try:
            streaming_response = await asyncio.to_thread(
                self.client.invoke_model_with_response_stream,
                modelId=model_id,
                body=json.dumps(body),
            )

            for event in streaming_response["body"]:
                chunk = json.loads(event["chunk"]["bytes"])
                if "generation" in chunk:
                    yield chunk["generation"]
                if "amazon-bedrock-invocationMetrics" in chunk:
                    yield chunk["amazon-bedrock-invocationMetrics"]

        except Exception as e:
            exception_type = type(e).__name__
            exception_message = str(e)
            exception_traceback = traceback.extract_tb(e.__traceback__)
            line_number = exception_traceback[-1].lineno

            print(f"Exception Type: {exception_type}")
            print(f"Exception Message: {exception_message}")
            print(f"Line Number: {line_number}")
            print("Full Traceback:")
            print("".join(traceback.format_tb(e.__traceback__)))
            yield {"error": 500, "reason": str(e)}

    async def _chat_formatter(
        self,
        user_message: Union[str, List[Dict[str, str]]],
        chat_hist: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
        do_json: Optional[bool] = False,
    ) -> List[Dict]:
        try:
            messages = []

            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            if chat_hist:
                messages.extend(chat_hist)

            if isinstance(user_message, str):
                if do_json:
                    messages.extend(
                        [
                            {"role": "user", "content": user_message},
                            {"role": "assistant", "content": "{"},
                        ]
                    )
                else:
                    messages.extend(
                        [
                            {"role": "user", "content": user_message},
                            {"role": "assistant", "content": ""},
                        ]
                    )
            elif isinstance(user_message, List):
                messages.extend(user_message)

            if messages[-1].get("role") == "user":
                return self.tokenizer.apply_chat_template(messages, tokenize=False)
            elif messages[-1].get("role") == "assistant":
                return self.tokenizer.decode(
                    self.tokenizer.apply_chat_template(messages, tokenize=True)[:-1]
                )
            else:
                raise KeyError(
                    """invalid role given in messages list, this error should not happen due to the validation steps being used.\
                    Please check the validation function"""
                )

        except Exception as e:
            exception_type = type(e).__name__
            exception_message = str(e)
            exception_traceback = traceback.extract_tb(e.__traceback__)
            line_number = exception_traceback[-1].lineno

            print(f"Exception Type: {exception_type}")
            print(f"Exception Message: {exception_message}")
            print(f"Line Number: {line_number}")
            print("Full Traceback:")
            print("".join(traceback.format_tb(e.__traceback__)))
            return {"error": 500, "reason": str(e)}
